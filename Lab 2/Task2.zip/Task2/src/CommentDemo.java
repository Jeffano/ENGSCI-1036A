/**
 * Write a description of class CommentDemo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CommentDemo
{
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  x   a sample parameter for a method
     * @return     x square
     */
    public int squareFunction(int x)
    {
        // returns the square of x
        return x * x;
    }
}
