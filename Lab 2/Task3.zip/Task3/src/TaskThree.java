/**
 * Name: Jeffano John
 * Date: September 30th 2021
 * Student Number: 251230759
 * Description: This program declares and assigns variables. It then prints the information in a statement.
 */
public class TaskThree {
    public static void main(String args[] ){

        //Declaring Variables
        String strName;
        int intAge;
        double annualPay;

        //Assigning the variables
        strName = "Jeffano" ;
        intAge = 18;
        annualPay = 100000;

        //Printing final statement
        System.out.println("My name is " + strName + ". I am " + intAge + " years old. \nI wish to earn $" + annualPay);
    }
}
