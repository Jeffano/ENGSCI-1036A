public class Task1 {
    public static void main(String[] args){
        //Printing "Welcome to ES1036a course!" statement
        System.out.println("Welcome to ES1036a course!");
    }
}
