public class Task2 {
    public static void main(String[] args) {

        //Printing a Hello World statement by passing names through two arguments
        System.out.println("Hello, World! My name is " + args[0] + " " + args[1]);
    }
}
